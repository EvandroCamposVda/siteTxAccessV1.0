<?php
include_once "src/partials/_head.php";
include_once "src/partials/_header.php";
include_once "src/partials/_navegation.php";
?>
	<div class="container">
		<div class="col-12 md-12" id="SobreEmpresa">
			<h1>Sobre</h1>
			<p>A empresa TX atua a "anos" no mercado, com uma equipe de profissionais qualificados para melhor atender o cliente. A TX tem como foco entregar produtos de alta qualidade com o melhor do mercado para seu cliente. </p>
		</div>

		<div class="col-12 md-12" id="logosEmpresa">
			<img src="img/logo1.png" alt="Logo TxTecnologia" width="400px">
			<img src="img/logo.png" alt="Logo TxAccess" width="200px">
		</div>
	</div>
<?php include_once "src/partials/_footer.php"; ?>