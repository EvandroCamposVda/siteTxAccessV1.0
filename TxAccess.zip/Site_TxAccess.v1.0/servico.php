<?php
include_once "src/partials/_head.php";
include_once "src/partials/_header.php";
include_once "src/partials/_navegation.php";
?>
	<div class="container">
		<div class"col-sm-12 col-md-12" id="Servico">
			<h1 align="center">Serviços</h1>
			
			<div class"md-12 col-12" align="left" id="ServicoDisplay">
				<div>
					<h1>Relógio Ponto</h1>
				</div>
				<div>
					<p>A empresa Tx atua a "anos" no mercado, com uma equipe de profissionais qualificados para melhor atender o cliente. A TX tem como foco entregar produtos de alta qualidade com o melhor do mercado para seu cliente.</p>
				</div>
			</div>

			<div class"md-12 col-12" align="right">
				<h1>Sistemas de Controle</h1>
				<p>Nós buscamos sempre os melhores produtos para o cliente, com uma parceria de "anos" com a Secullum Softwares entregamos o melhor de seus produtos para nossos clientes.</p>
			</div>

			<div class"md-12 col-12" align="left">
				<h1>Camera</h1>
				<p>Para o melhor ao cliente nós vendemos as melhores marcas do mercado. Produtos de alta qualidade com o que há de melhor no mercado.</p>
			</div>

			<div class"md-12 col-12" align="right">
				<h1>Alarme</h1>
				<p>Para os clientes com uma necessecidade maior do controle de sua residencia/estabelecimento nós temos o melhor do mercado para oferecer, com inumeras opções de combinações para nossos clientes.</p>
			</div>
		</div>
	</div>
<?php include_once "src/partials/_footer.php"; ?>