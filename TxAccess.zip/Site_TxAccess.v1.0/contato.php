<?php
include_once "src/partials/_head.php";
include_once "src/partials/_header.php";
include_once "src/partials/_navegation.php";
?>
	<div class="container">
		<div class="md-12 col-12" id="contatos">
			<h1>Contatos</h1>
			<div class=" col-12 md-12" id="contatosUsuario">
				<div class="col-5 md-6">
					<h2>Suporte</h2>
			
					<ul>
						<li>Skype: suportetxtech02</li>
						<li>E-mail: suportetxaccess01@gmail.com</li>
						<li>WhatsApp: (49) 99938-5432</li>
						<li>Telefone: (49) 3533-3014</li>
						
					</ul>
				</div>

				<div class="col-5 md-6" align="right">
					<h2>Comercial</h2>
				
					<ul>
						<li>Skype: evandrotxtech</li>
						<li>E-mail: comercialtxaccess@gmail.com</li>
						<li>WhatsApp: (49) 99926-0266</li>
						<li>Telefone: (49) 3533-3014</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
<?php include_once "src/partials/_footer.php"; ?>