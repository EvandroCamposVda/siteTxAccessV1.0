<?php
include_once "src/partials/_head.php";
include_once "src/partials/_header.php";
include_once "src/partials/_navegation.php";
?>
	<div class="album text-muted">
		<div class="container">
			<div class="col-12 md-12">
				<div class="row" id="clientes">
					<div></div>
					<div class="card" id="clientesCard">
						<a href="https://master.agr.br/unidade/master-videira/"><img src="img/logos/master.png" alt="Master"></a>
						<ul class="list-group list-group-flush">
							<li class="list-group-item"><a href="src/henry/henry.php">Relógio Ponto</a></li>
						</ul>
					</div>

					<div class="card" id="clientesCard">

						<a href="http://menpet.com.br"><img src="img/logos/manpet.png" alt="ManPet"></a>
							<ul class="list-group list-group-flush">
								<li class="list-group-item"><a href="src/secullum/ponto4/index.php">Ponto Secullum 4</a></li>
								<li class="list-group-item"><a href="src/topdata/relogio/topdata.php">Relógio Ponto</a></li>
							</ul>
					</div>

					<div class="card" id="clientesCard">
						<a href="https://www.facebook.com/encoplac.engenharia"><img src="img/logos/encoplac.jpg" alt="Encoplac"></a>
							<ul class="list-group list-group-flush">
								<li class="list-group-item"><a href="src/secullum/ponto4/index.php">Ponto Secullum 4</a></li>
								<li class="list-group-item"><a href="src/topdata/relogio/topdata.php">Relógio Ponto</a></li>
							</ul>
					</div>

					<div class="card" id="clientesCard">
						<a href="http://www.casafaisca.com.br/"><img src="img/logos/casaFaisca.png" alt="Casa Faisca"></a>
							<ul class="list-group list-group-flush">
								<li class="list-group-item"><a href="src/secullum/ponto4/index.php">Ponto Secullum 4</a></li>
								<li class="list-group-item"><a href="src/topdata/relogio/topdata.php">Relógio Ponto</a></li>
							</ul>
					</div>

					<div class="card" id="clientesCard">
						<a href="http://www.fbengenharia.com/"><img src="img/logos/fbEngenharia.png" alt="FB Engenharia"></a>
							<ul class="list-group list-group-flush">
								<li class="list-group-item"><a href="src/secullum/ponto4/index.php">Ponto Secullum 4</a></li>
								<li class="list-group-item"><a href="src/topdata/relogio/topdata.php">Relógio Ponto</a></li>
							</ul>
					</div>

					<div class="card" id="clientesCard">
						<a href="https://brancalione.com.br/"><img src="img/logos/brancalione.png" alt="Frigorifico Brancalione"></a>
							<ul class="list-group list-group-flush">
								<li class="list-group-item"><a href="src/secullum/ponto4/index.php">Ponto Secullum 4</a></li>
								<li class="list-group-item"><a href="src/topdata/relogio/topdata.php">Relógio Ponto</a></li>
							</ul>
					</div>

					<div class="card" id="clientesCard">
						<a href="http://www.harmonize.ind.br"><img src="img/logos/harmonize.png" alt="Harmonize"></a>
							<ul class="list-group list-group-flush">
								<li class="list-group-item"><a href="src/secullum/ponto4/index.php">Ponto Secullum 4</a></li>
								<li class="list-group-item"><a href="src/henry/henry.php">Relógio Ponto</a></li>
							</ul>
					</div>

					<div class="card" id="clientesCard">
						<a href="http://bebidaspinheirense.com.br"><img src="img/logos/pinheirense.jpg" alt="Pinheirense"></a>
							<ul class="list-group list-group-flush">
								<li class="list-group-item"><a href="src/secullum/ponto4/index.php">Ponto Secullum 4</a></li>
								<li class="list-group-item"><a href="src/henry/henry.php">Relógio Ponto</a></li>
							</ul>
					</div>

					<div class="card" id="clientesCard">
						<a href="http://www.madebrac.com.br/"><img src="img/logos/madebrac.png" alt="Madebrac"></a>
							<ul class="list-group list-group-flush">
								<li class="list-group-item"><a href="src/secullum/ponto4/index.php">Ponto Secullum 4</a></li>
								<li class="list-group-item"><a href="src/henry/henry.php">Relógio Ponto</a></li>
							</ul>
					</div>

					<div class="card" id="clientesCard">
						<a href="http://www.moveisfrarao.com.br/"><img src="img/logos/moveisFrarao.png" alt="Moveis Frarão"></a>
							<ul class="list-group list-group-flush">
								<li class="list-group-item"><a href="src/secullum/ponto4/index.php">Ponto Secullum 4</a></li>
								<li class="list-group-item"><a href="src/topdata/relogio/topdata.php">Relógio Ponto</a></li>
							</ul>
					</div>

					<div  class="card" id="clientesCard">
						<a href="http://www.videfrigo.com.br/"><img src="img/logos/videfrigo.png" alt="VideFrigo"></a>
						<ul class="list-group list-group-flush">
							<li class="list-group-item"><a href="src/secullum/ponto4/index.php">Ponto Secullum 4</a></li>
							
						</ul>
					</div>

					<div  class="card" id="clientesCard">
						<a href="https://www.facebook.com/vidaesaudejoacaba/"><img src="img/logos/vidaSaude.png" alt="Academia Vida e Saude"></a>
						<ul class="list-group list-group-flush">
							<li class="list-group-item"><a href="src/secullum/academia/index.php">Academia.net</a></li>
						</ul>
					</div>

				</div>
			</div>
		</div>
	</div>
<?php include_once "src/partials/_footer.php"; ?>