<?php
include_once "../../partials/_head.php";
include_once "../../partials/_header.php";
include_once "../../partials/_navegation.php";
?>
	<div class="container" id="catracaFitConteudo">
		<div class="col-12">
			<div id="catracaFit">
				<h1>Catraca Fit</h1>
				<div class="col-sm-12 col-md-12" id="slidesPontoSecullum4" align="center">
		
					<div id="catracaFir" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
							<li data-target="#catracaFir" data-slide-to="0" class="active"></li>
							<li data-target="#catracaFir" data-slide-to="1"></li>
							<li data-target="#catracaFir" data-slide-to="2"></li>
							<li data-target="#catracaFir" data-slide-to="3"></li>
							<li data-target="#catracaFir" data-slide-to="4"></li>
						</ol>	

						<div class="carousel-inner" role="listbox" id="imgSlidesPontoSecullum4">
							<div class="carousel-item active">
								<img class="d-block img-fluid" src="img/img1.png" alt="First slide" height="1070px" width="900px" align="center">
							</div>
							<div class="carousel-item">
								<img class="d-block img-fluid" src="img/img2.png" alt="third slide"  height="1070px" width="900px">
							</div>
							<div class="carousel-item">
								<img class="d-block img-fluid" src="img/img3.png" alt="quarter slide"  height="1070px" width="900px">
							</div>
							<div class="carousel-item">
								<img class="d-block img-fluid" src="img/img4.png" alt="five slide"  height="1070px" width="900px">	
							</div>
						</div>

						<a class="carousel-control-prev" href="#catracaFir" role="button" data-slide="prev">
							<span class="carousel-control-prev-icon" aria-hidden="true"></span>
							<span class="sr-only">Previous</span>
						</a>
			
						<a class="carousel-control-next" href="#catracaFir" role="button" data-slide="next">
							<span class="carousel-control-next-icon" aria-hidden="true"></span>
							<span class="sr-only">Next</span>
						</a>
					</div>
				</div>
			</div>

			<div id="accordion">
					<div class="card">
						<div class="card-header" id="headingOne">
							<h5 class="mb-0" align="center">
							<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
								Caracteristicas                                      
							</button>
							</h5>
						</div>
						<div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
							<div class="card-body">
								<ul>
									<li>* Capacidade de armazenamento de até 10.000 digitais</li>
									<li>* Leitor de proximidade de 125KHz</li>
									<li>* Capacidade para armazenamento de até 30.000 registros</li>
									<li>* Lista para controle de acesso de até 15.000 usuarios</li>
									<li>* Permite cadastro de 10 funções de especiais configuraveis</li>
									<li>* Função de contador de giros visualizados no software gerenciador de Inners 5</li>
									<li>* A Fit é inteligente porque coleta dados sobre o fluxo dos usuários. Com essas informações, é possível ter um relatório que mostra o histórico de acesso e de frequência.</li>
									<li>* Ela pode ser usada de duas formas: online ou off-line. No primeiro modo, a catraca permanece conectada a um sistema de acesso. Sem conexão, sem problemas. A Fit também opera de forma autônoma e off-line.</li>
									<li>* Pode ser usada em academias para controlar o acesso dos alunos ou em prédios comerciais e industrias para monitorar o fluxo de funcionários e visitantes. A Catraca Fit também pode ser usada em eventos, como show, feiras e exposições.</li>
									<li>* A catraca Fit é uma forma prática para controlar o fluxo de pessoas a qualquer local. A Fit se adapta a todos ambientes porque tem um design atual, simples e compacto.</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>		
	</div>
</div>

<?php include_once "../../partials/_footer.php"?>