	<footer  id="footer">
		<div  id="site">
			<ul class="part1">
				<li><p><a href="../../../src/secullum/ponto4/index.php">Ponto Secullum 4</a></p></li>
				<li><p><a href="../../../src/secullum/academia/index.php">Mini Academia.net</a></p></li>
				<li><p><a href="../../../src/henry/henry.php">Prisma Super Facil Advance</a></p></li>
				<li><p><a href="../../../../src/topdata/relogio/topdata.php">Inner Rep Plus</a></p></li>
				<li><p><a href="../../../../src/topdata/catraca/index.php">Catraca TopData</a></p></li>
				<li><p><a href="../../../../src/viaweb/viaweb.php">Alarme</a></p></li>
				<li><p><a href="../../../../contato.php">Contatos</a></p></li>
			</ul>
		</div>

		<div id="comunication">
			<ul>
				<li>
					<img src="../../../img/telefone.png" width="38px" height="38px">
					<p>(49) 3533-3014</p>
				</li>
				<li>
					<img src="../../../img/whatsapp.png" width="38px" height="38px">
					<p class="pMeio">(49) 99938-5432 / (49) 99926-0266</p>
				</li>
				<li>
					<a href=""><img src="../../../img/facebook.png" width="38px" height="38px"></a>
					<p>TxAccess Sistemas de Acesso</p>
				</li>
			</ul>
		</div>
	</footer>
</body>
</html> 