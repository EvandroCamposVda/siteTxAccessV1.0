<?php
include_once "../partials/_head.php";
include_once "../partials/_header.php";
include_once "../partials/_navegation.php";
?>
	
	<div class="container">
		<div class="col-12" id="CentralViaWebSystem">
			<h1 align="center">Central VW8Z IP Star</h1>

			<div class="col-12" id="slidesCentralViaWeb" align="center">
				<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
						<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
					</ol>	

					<div class="carousel-inner" role="listbox">
						<div class="carousel-item active">
							<img class="d-block img-fluid" src="img/centralvw8zip/img1.png" alt="Central ViaWebSystem vw8" width="450px" height="auto">
						</div>
						<div class="carousel-item">
						<img class="d-block img-fluid" src="img/centralvw8zip/img2.png" alt="Central ViaWebSystem vw8" width="450px" height="auto">
						</div>
					</div>

					<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
						<span class="carousel-control-prev-icon" aria-hidden="true"></span>
						<span class="sr-only">Previous</span>
					</a>
					
					<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
						<span class="carousel-control-next-icon" aria-hidden="true"></span>
						<span class="sr-only">Next</span>
					</a>
				</div>
			</div>
			<div id="accordion">
				<div class="card">
					<div class="card-header" id="headingOne">
						<h5 class="mb-0" align="center">
						<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
							Caracteristicas                                      
							</button>
						</h5>
					</div>
					<div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
						<div class="card-body">
							<ul>
								<li>* Comunicador IP integrado;</li>
								<li>* Compatível com aplicativo VIAWEBmobile</li>
								<li>* 8 zonas, expansível;</li>
								<li>* 8 partições;</li>
								<li>* Permite utilização de receptor de 12 setores + 12 controles sem fio (opcional);</li>
								<li>* Ajuste de relógio automático com horário de verão</li>
								<li>* Permite enviar e-mail;</li>
								<li>* Até 900 usuários;</li>
								<li>* Buffer 2048 eventos;</li>
								<li>* Até 8 teclados;</li>
								<li>* 2 saídas programáveis;</li>
								<li>* 2 sirenes particionadas;</li>
								<li>* 1 saída de sirene de 2,5A;</li>
								<li>* Saída auxiliar de 1,2A;</li>
								<li>* Fonte chaveada (110 – 240 VCA);</li>
								<li>* Totalmente programável através do software gratuito VIAWEB download;</li>
								<li>* Servidor web embarcado para operação e programação. Com o servidor interno é possível programar a central e todos os periféricos utilizando um computador conectado à rede local (sem o uso de teclado).</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div id="ViaWebParaMaisInformacao" class="col-12" align="center">
			<iframe width="560" height="315" src="https://www.youtube.com/embed/Rq44VUN40jA" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
			<h5>Para mais informações acesse: <a href="http://www.viawebsystem.com.br">ViaWeb</a></h5>
		</div>
	</div>
<?php include_once "../partials/_footer.php"; ?>