<?php
include_once "src/partials/_head.php";
include_once "src/partials/_header.php";
include_once "src/partials/_navegation.php";
?>
	<div class="container">
		<div class="md-12 col-12" id="contatos">
			<h1>Suporte</h1>
			<div class=" col-12 md-12" id="contatosUsuario">
				<div class="col-5 md-6">
					<h3>Evandro Campos</h3>
					<ul>
						<li>Skype: suportetxtech02</li>
						<li>E-mail: suportetxaccess01@gmail.com</li>
						<li>WhatsApp: (49) 99938-5432</li>
						<li>Telefone: (49) 3533-3014</li>
					</ul>
				</div>
				<div class="col-5 md-6">
					<table class="table">
						<tbody>
							<tr>
								<th scope="row">Segunda-Feira</th>
								<td>13:30 - 18:30</td>
							</tr>
							<tr>
								<th scope="row">Terça-Feira</th>
								<td>13:30 - 18:30</td>
							</tr>
							<tr>
								<th scope="row">Quarta-Feira</th>
								<td>13:30 - 18:30</td>
							</tr>
							<tr>
								<th scope="row">Quinta-Feira</th>
								<td>13:30 - 18:30</td>
							</tr>
							<tr>
								<th scope="row">Sexta-Feira</th>
								<td>13:30 - 18:30</td>
							</tr>
						</tbody>
					</table>
				</div>

			</div>
		</div>
	</div>
<?php include_once "src/partials/_footer.php"; ?>