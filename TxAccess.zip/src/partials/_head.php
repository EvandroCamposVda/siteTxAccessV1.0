<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="keywords" content="Relogio Ponto SC, Tx, Access, Cameras, Alarme, videira">
	
	<link rel="sortcut icon" href="../../../../../img/minilogo.png" type="image/png" />

	<meta name="author" content="Evandro Campos">


	<link rel="stylesheet" href="../../../../css/reset.css">
	<link rel="stylesheet" href="../../../../css/bootstrap-reboot.min.css">
    <link rel="stylesheet" href="../../../../css/bootstrap.min.css">
	<link rel="stylesheet" href="../../../../css/bootstrap-grid.min.css">
	<link rel="stylesheet" href="../../../../css/style.css">
	
	<script src="../../../../js/jquery.min.js"></script>
    <script src="../../../../js/bootstrap.min.js"></script>
	<script src="../../../../js/bootstrap.bundle.min.js"></script>
	
	<title>Tx Access Sistemas de Ponto</title>
</head>