<nav class="navbar navbar-expand-lg navbar-light bg-light" id="BackGroundNav">
    <div class="col-12" id="backgroundNavBar">
        <div clas="col-md-4" id="backgroundNavBarImg">    
            <div id="navbarImg">    
                <img src="../../../../../../img/logo.png" height="120" width="auto" class="img" alt="Logo Tx Access">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
        </div>
        <div class="col-8" id="backgroundNavBarList">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto" id="barraInicial">
                    <li class="nav-item"><a class="nav-link" href="../../../../../index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="../../../../../sobre.php">Sobre</a></li>
                    <li class="nav-item"><a class="nav-link" href="../../../../../clientes.php">Clientes</a></li>
                    <li class="nav-item"><a class="nav-link" href="../../../../../contato.php">Contato</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Serviços
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown"> 
                            <a class="dropdown-item" href="../../../../../src/topdata/relogio/topdata.php">Relógio Ponto</a>
                            <a class="dropdown-item" href="../../../../../src/topdata/catraca/index.php">Catraca</a>
                            <a class="dropdown-item" href="../../../../../src/secullum/ponto4/index.php">Secullum Ponto 4</a>
                            <a class="dropdown-item" href="../../../../../src/secullum/academia/index.php">Secullum Academia.net</a>
                            <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="../../../../../src/viaweb/viaweb.php">Alarmes</a>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>