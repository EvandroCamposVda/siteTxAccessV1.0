<?php
include_once "../../partials/_head.php";
include_once "../../partials/_header.php";
include_once "../../partials/_navegation.php";
?>
	<div class="container">
		<div class="col-12">
			
			<div id="VideoTopData">
				<h1>Inner Rep Plus</h1>
				<iframe src="https://fast.wistia.net/embed/iframe/n1u2o587mq?dnt=1&amp;videoFoam=true" title="Wistia video player" allowtransparency="true" frameborder="0" scrolling="no" class="wistia_embed" name="wistia_embed" allowfullscreen="allowfullscreen" mozallowfullscreen="mozallowfullscreen" webkitallowfullscreen="webkitallowfullscreen" oallowfullscreen="oallowfullscreen" msallowfullscreen="msallowfullscreen" width="640" height="360" style="width: 640px; height: 360px;"></iframe>
			</div>
			
			<div id="accordion">
				<div class="card">
					<div class="card-header" id="headingOne">
					<h5 class="mb-0" align="center">
					<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
						Caracteristicas                                      
						</button>
					</h5>
					</div>
					<div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
						<div class="card-body">
							<ul>
								<li>* O relógio de ponto eletrônico Inner Rep Plus é um produto homologado pelo MTE e pelo INMETRO.</li>
								<li>* O Inner REP Plus permite o controle de ponto para todos os portes de empresas, oferecendo segurança jurídica para o empregador, facilitando a gestão de recursos humanos e garantindo o controle fiel das marcações dos empregados.</li>
								<li>* O empregado registra o ponto usando seu cartão de identificação, por biometria ou ainda pelo teclado sensível ao toque;</li>
								<li>* O REP armazena esse registro na memória e imprime o comprovante do trabalhador com assinatura digital que impede sua falsificação;</li>
								<li>* Por fim o relógio permite exportar as marcações para tratamento no sistema de controle de ponto pela rede de dados ou pela porta USB auxiliar.</li>
								<li>* O MTE fiscaliza os registros de ponto eletrônico, coletando as marcações registradas na memória do equipamento através de um pendrive conectado à porta USB Fiscal.</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="card">
					<div class="card-header" id="headingTwo">
					<h5 class="mb-0" align="center">
						<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
							Por que usar um relógio de ponto eletrônico homologado ?                                      
						</button>
					</h5>
					</div>
					<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
						<div class="card-body">
							<p>Desde 01 de março de 2011 é exigido pelo Ministério do Trabalho que, empresas que registram o ponto de seus funcionários de maneira eletrônica, utilizem relógios homologados pelo Ministério e atualmente é obrigatório que os fabricantes produzam relógios aprovados pelo INMETRO para garantir que apresentem requisitos mínimos para que registrem fielmente as marcações de ponto.</p>
						</div>
					</div>
				</div>
			</div>
			<div id="SaberMaisTopData">
				<h5 align="center">Para saber mais acesse: <a href="https://www.topdata.com.br/relogio-ponto-biometrico/">Topdata</a></h5>
			</div>
		</div>
	</div>
		

		<?php include_once "../../partials/_footer.php"; ?>