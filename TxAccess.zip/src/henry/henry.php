<?php
include_once "../partials/_head.php";
include_once "../partials/_header.php";
include_once "../partials/_navegation.php";
?>

	<div class="container" id="PrismaSuperFacilAdvance">
	<h3 align="center">Prisma Super Facil Advance</h3>
	<p>O Prisma Super Fácil Advanced é um relógio de ponto eletrônico (REP) homologado pelo MTE e certificado pelo Inmetro. Disponível em 5 modelos diferentes, possui tela touch screen e diversas opções de identificação como biometria, códigos de barras, proximidade RFID e Smart Card. Sua nova tecnologia com recursos e funcionalidades otimizadas, proporcionam ao usuário um registro de ponto seguro e eficaz. Ideal para todos os segmentos e portes de empresas.</p>
		
		<div class="col-12" id="slidesRelogioHenryPrisma" align="center">

			<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
				<ol class="carousel-indicators">
					<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
					<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
					<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
					<li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
					<li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
					<li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
				</ol>	

				<div class="carousel-inner" role="listbox">
					<div class="carousel-item active">
						<img class="d-block img-fluid" src="img/img1.1.png" alt="Relogio Ponto Prisma Super Facil Advance">
					</div>
					<div class="carousel-item">
						<img class="d-block img-fluid" src="img/img1.2.png" alt="Relogio Ponto Prisma Super Facil Advance">
					</div>
					<div class="carousel-item">
						<img class="d-block img-fluid" src="img/img2.1.png" alt="Relogio Ponto Prisma Super Facil Advance">
					</div>
					<div class="carousel-item">
						<img class="d-block img-fluid" src="img/img2.2.png" alt="Relogio Ponto Prisma Super Facil Advance">
					</div>
					<div class="carousel-item">
						<img class="d-block img-fluid" src="img/img3.1.png" alt="Relogio Ponto Prisma Super Facil Advance">
					</div>
					<div class="carousel-item">
						<img class="d-block img-fluid" src="img/img3.2.png" alt="Relogio Ponto Prisma Super Facil Advance">
					</div>
				</div>

				<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				</a>
				
				<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				</a>
			</div>
		</div>


			
		<div id="accordion">
			<div class="card">
				<div class="card-header" id="headingOne">
				<h5 class="mb-0" align="center">
				<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
					Caracteristicas                                      
					</button>
				</h5>
				</div>
				<div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
					<div class="card-body">
						<ul>
							<li>* Capacidade de gerenciamento de até 15.000 colaboradores na Memória de Trabalho (MT)</li>
							<li>* Capacidade para armazenamento de registros em memória (MRP): 3.500.000</li>
							<li>* Maior nível de segurança, com dados fiscais assinados digitalmente</li>
							<li>* Comunicação protegida por criptografia, impedindo qualquer tentativa de fraude via softwares não autorizados</li>
							<li>* Sistema interno de sensores que realizam o bloqueio automático do equipamento, na tentativa violação</li>
							<li>* Controle das operações realizadas no equipamento, através de níveis de acesso concedidas pelo usuário administrador do sistema</li>
							<li>* Utiliza sistema de gerenciamento embarcado através de navegador web, sem necessidade de instalação de software na máquina cliente</li>
							<li>* Permite cadastrar colaborador e digital, diretamente no equipamento sem a necessidade de utilizar o webserver ou um software gerenciador</li>
							<li>* Interface touch com teclado QWERT para facilitar o cadastro local no próprio equipamento</li>
							<li>* Imprime até 11.000 mil tickets por bobina</li>
							<li>* Os dados são gravados em memória não volátil tanto para a Memória de Trabalho (MT) como para a Memória de Registro Permanente (MRP)</li>
							<li>* Permite o cadastro das informações do empregador, local de trabalho e colaboradores</li>
							<li>* Armazena na MRP os eventos: registro do empregador, marcação de ponto, alteração de data e hora, cadastro e alteração de colaboradores e eventos 	sensíveis</li>
							<li>* Trabalha com vários tipos de comunicação, tornando-se um equipamento moldável à necessidade do cliente e adaptável ao ambiente</li>
							<li>* Calendário perpétuo, com opção de ajuste da data e hora e configuração do horário de verão</li>
							<li>* O equipamento trabalha com leitura automática da quantidade de dígitos dos cartões (3 a 20 dígitos)Possui botão na cor vermelha identificado como RIM, que tem a função de extrair a relação impressa das marcações de ponto realizadas nas 24 horas precedentes</li>
							<li>* Possui botão na cor vermelha identificado como RIM, que tem a função de extrair a relação impressa das marcações de ponto realizadas nas 24 horas precedentes</li>
							<li>* Possui botão na cor azul que tem a função de imprimir o identificador do software e chave pública do equipamento</li>
							<li>* Possui porta fiscal USB para coleta do arquivo AFD para auditoria dos dados do equipamento pelo fiscal do trabalho</li>
							<li>* Para maior controle do acesso ao equipamento, possui suporte para cadastrar um usuário e senha de acesso para controle das configurações</li>
							<li>* Suporta até oito usuários para gerenciar o equipamento</li>
							<li>* Oferece suporte para cadastro de cartão do usuário para acesso ao menu</li>
							<li>* Capacidades de armazenamento de digitais: 15.000, ou 19.500 digitais (opcional)</li>
							<li>* Opera com Auto On (biometria com recurso de toque único), função que permite realizar a identificação da digital apenas colocando o dedo sobre o sensor, sem a necessidade de digitar a matrícula ou utilizar o crachá</li>
							<li>* Sistema de importação e exportação de dados via segunda porta USB. Através desta porta podem ser realizadas as configurações do equipamento, do empregador, de colaboradores, de biometrias e coleta de eventos</li>
							<li>* Permite realizar exportação da chave pública através da porta USB2, salvando-a em arquivo de texto em um dispositivo USB de armazenamento</li>
							<li>* Sistema de identificação de status e eventos no equipamento: pelo próprio equipamento, aplicativo embarcado ou software gerenciador</li>
							<li>* Possui sistema de gerenciamento inteligente. Valida as informações recebidas e as salva apenas se for necessário, otimizando a utilização da memória</li>
							<li>* Possui sensor para garantir a impressão do comprovante de ponto do trabalhador</li>
							<li>* Possui contador de tickets restantes (valor aproximado), de forma que o empregador saiba quantos tickets ainda podem ser impressos com determinada bobina de papel</li>
						</ul>	
					</div>
				</div>
			</div>
			<div class="card">
				<div class="card-header" id="headingTwo">
					<h5 class="mb-0" align="center">
						<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
							Modelos
						</button>
					</h5>
				</div>
				<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
					<div class="card-body">
						<ul>
							<li>
								<ul>
									<li>* R1 – BIOMETRIA/BARRAS/PROXIMIDADE/SMART CARD CONTACTLESS</li>
									<li>* R2 – BIOMETRIA/PROXIMIDADE</li>
									<li>* R3 – BIOMETRIA/BARRAS</li>
									<li>* R4 – BIOMETRIA/SMART CARD CONTACTLESS</li>
									<li>* R5 – BARRAS/PROXIMIDADE </li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</div>

			<section class="col-12" align="center" id="ParaSaberMaisHenry">
				<img src="img/henry-selo-revenda-autorizada-horiz.png" alt="Selo Revenda Autorizada" width="400px">
				<h5>Para mais informações acesse <a href="http://www.henry.com.br/relogio-ponto/prisma_super_facil_advanced">Henry</a></h5>
			</section>
		</div>
	</div>
<?php include_once "../partials/_footer.php"; ?>