<?php
include_once "../partials/_head.php";
include_once "../partials/_header.php";
include_once "../partials/_navegation.php";
?>
	<div class = "col-12">
	
	</div>
<?php include_once "../partials/_footer.php"; ?>