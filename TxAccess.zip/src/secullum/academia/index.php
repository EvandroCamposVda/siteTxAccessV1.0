<?php
include_once "../../partials/_head.php";
include_once "../../partials/_header.php";
include_once "../../partials/_navegation.php";
?>
<div class="col-12">
    <div class="col-12" id="academiaNetTopo">    
        <div class="col-3">
            <img src="img/academia.png" alt="Academia.net">
         </div>
        <div class="col-9">
            <h1 align="right">Academia.net</h1>
            <p align="right">Com o Secullum Academia.Net você torna a sua academia um local mais seguro, organizado e com um sistema automatizado. Tudo para ajudar o dia-a-dia do seu negócio e agilizar as informações mais úteis para você. Através do app, você acessa fichas de treino, acompanha dados financeiros, recebe notificações de vencimentos e solicita alterações cadastrais de forma rápida e prática.</p>
        </div>
    </div>

    <div class="col-12" id="academiaNetMeio">
        <h3>Caracteristicas do Produto</h3>
        <ul>
            <li><p>* Cadastro de Alunos, Funcionários e quaisquer tipos de pessoas envolvidas com a academia</p></li>
            <li><p>* Controle de fichas de Avaliação Física, Treinamentos e Anamnese</p></li>
            <li><p>* Compatível com a maoria dos equipamentos de Controle de Acesso, Captura de Imagens e Acionadores do mercado</p></li>
            <li><p>* Gestão de Contas a Receber e Mensalidades com opções para geração de Recibos, Boletos e controle de Cheques</p></li>
            <li><p>* Gestão de Contas a Pagar e relatórios de Fluxo de Caixa previstos, realizados e gráfico de evolução periódico</p></li>
            <li><p>* Configurações de avisos sobre vencimentos de mensalidades nos equipamentos de acesso</p></li>
            <li><p>* Tela especial simplificada para quitação de mensalidades e pesquisa de informações de pessoas</p></li>
        </ul>
    </div>
</div>
    
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" id="academiaNetBaixo" align="center">
<iframe allowtransparency="true" width="180" scrolling="no" height="80" frameborder="0" src="https://www.secullum.com.br/SeloRevenda.aspx?ri=5387&pb=0"></iframe>
	<ol class="carousel-indicators">
		<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
		<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
	</ol>	
	<div class="carousel-inner" role="listbox" id="academiaNetBaixoSlides">
		<div class="carousel-item active" align="center">
			<img class="d-block img-fluid" src="img/print01.png" alt="Academia.Net" height="1024px" width="700px">
		</div>
		<div class="carousel-item" align="center">
			<img class="d-block img-fluid" src="img/print02.png" alt="Academia.Net" height="1024px" width="700px">
		</div>
		<div class="carousel-item" align="center">
			<img class="d-block img-fluid" src="img/print03.png" alt="Academia.Net" height="1024px" width="700px">
        </div>
        <div class="carousel-item" align="center">
            <iframe width="600" height="350" src="https://www.youtube.com/embed/BdsRjIk4BWI" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
		</div>
	</div>

	<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
		<span class="carousel-control-prev-icon" aria-hidden="true"></span>
		<span class="sr-only">Previous</span>
	</a>
				
	<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
		<span class="carousel-control-next-icon" aria-hidden="true"></span>
		<span class="sr-only">Next</span>
	</a>
	</div>
</div>
<p align="center" id="academiaNetParaSaberMais">Para saber mais acesse <a href="https://novo.secullum.com.br/pt/produtos/academianet">Academia.Net</a></p>
<?php include_once "../../partials/_footer.php"; ?>